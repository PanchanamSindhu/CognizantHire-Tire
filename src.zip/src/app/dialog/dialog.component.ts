import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,Validator, Validators } from '@angular/forms';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {
 
  books: string[] = ['Chetan', 'Vikram', 'Narayan'];
  productForm!:FormGroup;

  constructor(private formBuilder:FormBuilder) {}
    
     ngOnInit(): void {
    this.productForm=this.formBuilder.group({
      bookName:['',Validators.required],
      bookCatergory:['',Validators.required],
      date:['',Validators.required],
      favAuthor:['',Validators.required],
      comment:['',Validators.required]
      
    });
   
  }
  addProduct(){
    console.log(this.productForm.value);
    alert("saved succesfully");
  }
  

}

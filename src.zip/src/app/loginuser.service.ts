import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService {
private baseUrl="http://localhost:8989/user/login";
  constructor(private _http:HttpClient) { }

  logingUser(u:User):Observable<any>{
      console.log(u);
      return this._http.post<any>(`${this.baseUrl}`,u);
    }
    signupUser(u:User):Observable<any>{
      console.log(u);
      this.baseUrl="http://localhost:8989/user/signup";
      return this._http.post<any>(`${this.baseUrl}`,u);
    }
}

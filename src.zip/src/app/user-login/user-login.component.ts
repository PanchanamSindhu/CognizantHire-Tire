import { Component, OnInit } from '@angular/core';
import { LoginuserService } from '../loginuser.service';
import { User } from '../user';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  user:User=new User;

  constructor(private userservice:LoginuserService) { }

  ngOnInit(): void {
  }
  userLogin(){
    console.log(this.user);
    this.userservice.loginUser(this.user).subscribe(data=>
      {alert("Login Succesfully")
    },error=>alert("Plese enter correct userId and password"))
      ;
  }

}

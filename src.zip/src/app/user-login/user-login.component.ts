import { Component, OnInit } from '@angular/core';
import { LoginuserService } from '../loginuser.service';
import {Router} from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.scss']
})
export class UserLoginComponent implements OnInit {
user=new User();
  constructor(private userservice:LoginuserService,private route:Router) { }

  ngOnInit(): void {
  }
  userlogin(){
    console.log(this.user);
    this.userservice.logingUser(this.user).subscribe(data => {alert("Login Sucesfull");
    this.route.navigate(['/home']);},
      error=>alert("Error : login failed"));
    
  }
}

import { LoginuserService } from '../loginuser.service';
import { User } from '../user';
import {Router} from '@angular/router';
import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validator,Validators} from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  user=new User();

  constructor(private userservice:LoginuserService,private route:Router) { }

  ngOnInit(): void {
  }
  signupU(){
    console.log("Data saving");
    this.userservice.signupUser(this.user).subscribe
    (
      data =>{
       alert("Account created successfully!!!");
      this.route.navigate(['']);
       
      },
      error =>console.log("Error")
    )
  }
}
